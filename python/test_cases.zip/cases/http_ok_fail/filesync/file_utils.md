### backup

```shell
python -m filesync get files.txt 192.168.234.129 --prefix backup/ -p ./
```

### restore накат на хост (put): выбор+атрибуты из restore.txt сессии, контент из files/

```shell
python -m filesync put backup/192.168.234.129__2026-06-07_18-04-13 192.168.234.129 --target-root / --yes
```

