#!/usr/bin/env bash
set -eu

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
echo $SCRIPT_DIR
CASE_DIR=$(dirname "$SCRIPT_DIR")
# Корень проекта = на 3 уровня выше tmux/ (структура: ROOT/run_cases/<case>/tmux).
# Определяем по пути скрипта, а не через git — чтобы работало и в копии без .git
# (важно для переносимости проекта в другую папку).
ROOT=$(cd "$SCRIPT_DIR/../../.." && pwd)

# Папка с данными mserver для этого кейса (rulesets, startup-config, logs, runs).
# Передаётся аргументом из tmux-yaml; относительный путь резолвится от папки кейса.
#   ./mserver -> run_cases/http_ok_fail/mserver
DATA_DIR="${1:?usage: run_server.sh <mserver-data-dir> (например ./mserver)}"
case "$DATA_DIR" in
  /*) ;;                                # абсолютный путь — как есть
  *)  DATA_DIR="$CASE_DIR/$DATA_DIR" ;; # относительный — от папки кейса
esac
DATA_DIR=$(cd "$DATA_DIR" && pwd)       # нормализуем в абсолютный

# Запускаемся из папки данных: туда же пишутся ./logs и ./runs/server.
cd "$DATA_DIR"

"$ROOT/.venv/bin/python3" "$ROOT/mserver.py" \
  --ip 0.0.0.0 \
  --mgmt-port 40032 \
  --rulesets-dir ./rulesets \
  --startup-config ./startup-config.json \
  --logs-dir ./logs
