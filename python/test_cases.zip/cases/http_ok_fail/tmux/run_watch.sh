#!/usr/bin/env bash
# Опрос одного endpoint в цикле с прокручиваемым таймлайном (history не теряется).
#
# Usage: run_watch.sh <PORT> <PATH> [INTERVAL_SEC]
#   run_watch.sh 40000 /health
#   run_watch.sh 40000 /data 0.5
#
# Каждая строка: ВРЕМЯ | HTTP-код | время ответа | тело
# либо явная причина при сбое: порт закрыт / таймаут / пустой ответ.

HOST=127.0.0.1
PORT="${1:?usage: run_watch.sh PORT PATH [INTERVAL_SEC]}"
REQ_PATH="${2:?usage: run_watch.sh PORT PATH [INTERVAL_SEC]}"
INTERVAL="${3:-0.5}"
URL="http://${HOST}:${PORT}${REQ_PATH}"
ERRFILE="$(mktemp)"
trap 'rm -f "$ERRFILE"' EXIT

echo "watch ${URL}  (interval ${INTERVAL}s, Ctrl-C для выхода)"
echo "------------------------------------------------------------"

while true; do
  ts=$(date '+%H:%M:%S')
  # Тело + строка метаданных (код и время ответа) в конце; ошибки curl -> ERRFILE.
  out=$(curl -s -S --max-time 2 -w $'\n%{http_code} %{time_total}s' "$URL" 2>"$ERRFILE")
  rc=$?
  if [ "$rc" -ne 0 ]; then
    case "$rc" in
      7)  reason="ПОРТ $PORT ЗАКРЫТ — connection refused";;
      28) reason="ТАЙМАУТ — нет ответа за 2s";;
      52) reason="ПУСТОЙ ОТВЕТ от сервера";;
      56) reason="СОЕДИНЕНИЕ РАЗОРВАНО при приёме";;
      *)  reason="ОШИБКА curl (rc=$rc): $(tr -d '\n' <"$ERRFILE")";;
    esac
    printf '%s | ERR  |        | %s\n' "$ts" "$reason"
  else
    meta=$(printf '%s' "$out" | tail -n1)
    code=$(printf '%s' "$meta" | cut -d' ' -f1)
    rtime=$(printf '%s' "$meta" | cut -d' ' -f2)
    body=$(printf '%s' "$out" | sed '$d' | tr '\n' ' ')
    printf '%s | %s  | %6s | %s\n' "$ts" "$code" "$rtime" "$body"
  fi
  sleep "$INTERVAL"
done
