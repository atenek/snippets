## Management http-server with code 200 201 500 

### Runs
[run_server](tmux/run_server.sh)
[run_watch](tmux/run_watch.sh) — параметризованный опрос: `run_watch.sh <PORT> <PATH> [INTERVAL]`

```shell
# примеры ручного запуска
bash tmux/run_watch.sh 40000 /health
bash tmux/run_watch.sh 40000 /data 0.5
```


## RUN via tmux using tmuxp
```shell
../../.venv/bin/tmuxp load tmux/tmux_sess_http_ok_fail.yaml
```

```shell
tmux kill-server
```

# mgmt
```shell
curl -s -X POST http://127.0.0.1:40032/mgmt -H "Content-Type: application/json" -d '[{"service": "tcp:40000", "mode": "http", "ruleset": "rules_200_ok"}]'
curl -s -X POST http://127.0.0.1:40032/mgmt -H "Content-Type: application/json" -d '[{"service": "tcp:40000", "mode": "http", "ruleset": "rules_201_ok"}]'
curl -s -X POST http://127.0.0.1:40032/mgmt -H "Content-Type: application/json" -d '[{"service": "tcp:40000", "mode": "http", "ruleset": "rules_500_fail"}]'
```

